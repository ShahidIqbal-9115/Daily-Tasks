import { Component } from '@angular/core';
import { RouterOutlet , RouterLink ,RouterLinkActive } from '@angular/router';
import { CommonModule } from '@angular/common';
import { LazyLOadingModule } from '../lazy-loading/lazy-loading.module';
import { ChildDataComponent } from './child-data/child-data.component';
import { ChildTwoComponent } from './child-two/child-two.component';
import { ChildThreeComponent } from './child-three/child-three.component';
import { ShareDataService } from '../Services/share-data.service';
import { ReactiveFormsModule } from '@angular/forms';

@Component({ 
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet , CommonModule, RouterLink,
     RouterLinkActive,LazyLOadingModule,ChildDataComponent,
    ChildTwoComponent, ChildThreeComponent,ReactiveFormsModule],
  providers:[ShareDataService],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {

  hiddenOne:boolean=false;
  hiddenTwo:boolean=false;
  hiddenThree:boolean=false;

  onClickOne(){
    this.hiddenOne=!this.hiddenOne;
    this.hiddenTwo=false;
    this.hiddenThree=false;
    console.log("g");
  }
  
  onClickTwo(){
    this.hiddenTwo=!this.hiddenTwo
    this.hiddenOne=false;
    this.hiddenThree=false;
    console.log("g");
  }

  onClickThree(){
  this.hiddenThree=!this. hiddenThree
  this.hiddenOne=false;
  this.hiddenTwo=false;
  console.log("g");
  }

  parentData1: string = 'Hello from Parent Component Child 1!';
  parentData2: string = 'Hello from Parent Component Child 2!';
  parentData3: string = 'Hello from Parent Component Child 3!';
  title = 'veroke Angular';
  
}
