import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AppDepartmentComponent } from './app-department.component';

describe('AppDepartmentComponent', () => {
  let component: AppDepartmentComponent;
  let fixture: ComponentFixture<AppDepartmentComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AppDepartmentComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AppDepartmentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
