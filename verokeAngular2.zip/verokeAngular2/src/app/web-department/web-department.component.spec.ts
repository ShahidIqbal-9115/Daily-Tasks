import { ComponentFixture, TestBed } from '@angular/core/testing';

import { WebDepartmentComponent } from './web-department.component';

describe('WebDepartmentComponent', () => {
  let component: WebDepartmentComponent;
  let fixture: ComponentFixture<WebDepartmentComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [WebDepartmentComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(WebDepartmentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
