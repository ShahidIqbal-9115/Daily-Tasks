import { Component ,OnInit} from '@angular/core';
import { Input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ShareDataService } from '../../Services/share-data.service';

@Component({
  selector: 'app-child-data',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './child-data.component.html',
  styleUrl: './child-data.component.css'
})
export class ChildDataComponent {

  // @Input() dataFromParent:string="";
  public Data:any;
  show:boolean=false;
  onClick(){
    this.show=!this.show;
  }
 
  constructor(private _services:ShareDataService){}

  ngOnInit() {
     this.Data = this._services.getData();
    //  alert("call");
  }
}
