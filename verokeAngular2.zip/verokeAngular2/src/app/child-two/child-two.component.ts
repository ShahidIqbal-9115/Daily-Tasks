import { Component } from '@angular/core';
import { Input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ShareDataService } from '../../Services/share-data.service';

@Component({
  selector: 'app-child-two',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './child-two.component.html',
  styleUrl: './child-two.component.css'
})
export class ChildTwoComponent {
  // @Input() dataFromParent:string="";
  show:boolean=false;
  onClick(){
    this.show=!this.show;
  }
  
  public Data:any; 
  constructor(private _services:ShareDataService){}

  ngOnInit() {
     this.Data = this._services.getData();
    //  alert("call");
  }
}
