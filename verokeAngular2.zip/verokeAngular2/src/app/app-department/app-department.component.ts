import { Component } from '@angular/core';

@Component({
  selector: 'app-app-department',
  standalone: true,
  imports: [],
  templateUrl: './app-department.component.html',
  styleUrl: './app-department.component.css'
})
export class AppDepartmentComponent {

}
