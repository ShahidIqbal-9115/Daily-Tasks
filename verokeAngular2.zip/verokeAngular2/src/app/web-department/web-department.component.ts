import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-web-department',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './web-department.component.html',
  styleUrl: './web-department.component.css'
})
export class WebDepartmentComponent {
  data = [
    {name:"derparments", component:"DepartmentComponent"},
    {name:"Webdeparment", component:"WebDepartmentComponent"},
    {name:"Appdeparment", component:"AppDepartmentComponent"},
    {name:"employee", component:"EmployeeComponent"}
];
    
}
