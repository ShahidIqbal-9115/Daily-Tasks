import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ShareDataService {

  constructor() {   }
  getData(){
    return[
    {"data":"Hello Child One this is Services1"},
    {"data":"Hello Child Two this is Services2"},
    {"data":"Hello Child Three this is Services3"}
    ]
  }
}
