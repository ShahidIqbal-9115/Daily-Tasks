import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule,FormControl, FormGroup ,Validator, Validators} from '@angular/forms';
// import { json } from 'stream/consumers';



@Component({
  selector: 'app-department',
  standalone: true,
  imports: [ReactiveFormsModule,CommonModule],
  templateUrl: './department.component.html',
  styleUrl: './department.component.css'
})
export class DepartmentComponent {

  registerationForm = new FormGroup({
    userName: new FormControl('',[Validators.required,Validators.minLength(3)]),
    email: new FormControl('',Validators.required),
    password: new FormControl('',[Validators.required,Validators.minLength(6)]),
    confirmPassword: new FormControl('',[Validators.required,Validators.minLength(6)]),
  });

  
  onSubmit() {
    if (this.registerationForm.invalid) {
      alert("Fill the Form");
    }
    else{
      console.log(this.registerationForm.value);
      this.registerationForm.reset();
    }

  }
}
