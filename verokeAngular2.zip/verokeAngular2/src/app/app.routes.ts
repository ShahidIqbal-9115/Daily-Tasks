import { Routes } from '@angular/router';
import { DepartmentComponent } from '../department/department.component';
import { EmployeeComponent } from '../employee/employee.component';
import { AppDepartmentComponent } from './app-department/app-department.component';
import { WebDepartmentComponent } from './web-department/web-department.component';
import { ChildComponent } from '../lazy-loading/child/child.component';
import { ChildDataComponent } from './child-data/child-data.component';
import { ChildTwoComponent } from './child-two/child-two.component';
import { ChildThreeComponent } from './child-three/child-three.component';

export const routes: Routes = [
    {path:"" , redirectTo: '/first-component', pathMatch: 'full'},
    {path:"deparments", component:DepartmentComponent},
    {path:"Webdeparment", component:WebDepartmentComponent},
    {path:"Appdeparment", component:AppDepartmentComponent},
    {path:"employee", component:EmployeeComponent},

    // {path:"child1", component:ChildDataComponent},
    // {path:"child2", component:ChildTwoComponent},
    // {path:"child3", component:ChildThreeComponent},

    // {
    //     path: 'employee', 
    //     loadChildren: () => import('../employee/employee.component').then(m => m.EmployeeComponent)
    // }
    
];
  
 
